### RASH-MD WHATSAPP BOT IN RUSH🔥

A fun WhatsApp bot.

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:87CEEB,100:87CEEB&height=180&section=header&text=RASH%20MD%20WHATSAPP%20BOT&fontSize=38&fontColor=ffffff&fontFamily=Roboto&animation=twinkling" width="100%"/>




<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=1BAFBAFF&center=true&width=810&height=100&lines=+THANKS FOR CHOOSING+RASH-MD;MULTI+DEVICE+WHATSAPP+BOT;CREATED+BY+RASH OWNER+RASHMIKA" alt="Typing SVG" /></a>
  </p>
  
--- 

<div align="center" class= "main"> 
  <img src="https://files.catbox.moe/4syeyx.jpg"width="300" height="300"/>


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

***





<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&pause=1000&width=435&lines=BEST+WHATSAPP+MULTIFUNCTIONAL+BOT+IN+RUSH-MD" alt="Typing SVG" /></a>
### ✧✧ This bot is still under development.✧✧
</br>
## ✧✧✧ NEW BOT MENU 1.0.0 

```
╔══════════════════╗
║ 𝑹𝑨𝑺𝑯 𝑴𝑫
╠══════════════════╣
║ 𝑯𝒆𝒍𝒍𝒐, 𝒅𝒆𝒂𝒓 ${pushname}
║ 𝑫𝒂𝒕𝒆: ${currentDate}
║ 𝑻𝒊𝒎𝒆: ${currentTime}
║ 𝑼𝒑𝒕𝒊𝒎𝒆: ${uptime}
║ 𝑶𝒘𝒏𝒆𝒓: ${config.OWNER_NAME}
║ 𝑴𝒐𝒅𝒆: ${config.MODE}
╚══════════════════╝

『 MAIN MENU 』
╭──────────────
┃ .alive
┃ .menu
┃ .ping
┃ .system
┃ .help
╰──────────────

『 DOWNLOAD MENU 』
╭──────────────
┃ .song <query>
┃ .video <query>
┃ .fb <link>
┃ .mediafire <link>
┃ .ig <link>
┃ .mfire <url>
┃ .gdrive <url>
┃ .tweet <url>
┃ .speak <query>
┃ .lyrics <song|artist>
┃ .weather <location>
┃ .gitclone <url>
╰──────────────

『 SEARCH MENU 』
╭──────────────
┃ .yts <query>
┃ .img <query>
╰──────────────

『 GROUP MENU 』
╭──────────────
┃ .grouplink
┃ .kickall
┃ .kickall2
┃ .kickall3
┃ .add
┃ .remove
┃ .kick
┃ .promote
┃ .demote
┃ .dismiss
┃ .revoke
┃ .setgoodbye
┃ .setwelcome
┃ .delete
┃ .getpic
┃ .ginfo
┃ .disappear on
┃ .disappear off
┃ .disappear 7D,24H
┃ .allreq
┃ .updategname
┃ .updategdesc
┃ .joinrequests
┃ .senddm
┃ .nikal
┃ .mute
┃ .unmute
┃ .lockgc
┃ .unlockgc
┃ .invite
┃ .tag
┃ .hidetag
┃ .tagall
┃ .tagadmins
╰──────────────

『 OWNER MENU 』
╭──────────────
┃ .shutdown
┃ .setpp
┃ .block
┃ .unblock
┃ .clearchats
┃ .restart
┃ .broadcast
╰──────────────

『 TOOLS MENU 』
╭──────────────
┃ .ai <query>
┃ .news <query>
┃ .hack
┃ .trt <info>
┃ .shorten <url>
┃ .fact
┃ .dalle <query>
┃ .ig <url>
┃ .pint <query>
┃ .insult
┃ .meme
┃ .url
╰──────────────

『 STALK MENU 』
╭──────────────
┃ .ghstalk <username>
╰──────────────

『 RELIGION MENU 』
╭──────────────
┃ .bible <chapter>:<verse>
┃ .quran <surah number>
╰──────────────

═════════════════════════════
𝑷𝑶𝑾𝑬𝑹𝑬𝑫 𝑩𝒀 𝑹𝑨𝑺𝑯 𝑻𝑬𝑪𝑯
𝑱𝑶𝑰𝑵 𝑶𝑼𝑹 𝑾𝑯𝑨𝑻𝑺𝑨𝑷𝑷 𝑪𝑯𝑨𝑵𝑵𝑬𝑳:
https://whatsapp.com/channel/0029VaZ
Type .repo to get bot info and deploy
══════════════════════
```
</br>

## ```Connect With Me```

<p align="center">

<a href="https://api.whatsapp.com/send?phone=940764409296&text=𝘩𝘦𝘭𝘭𝘰+𝘮𝘢𝘴𝘵𝘦𝘳"><img src="https://img.shields.io/badge/Contact rash style=for-the-badge&logo=whatsapp&logoColor=white" />

</p>



## ```Bot Support Groups```
<p align="center">

<a href="https://whatsapp.com/channel/0029VbAmpDr1iUxbOokrFK21"><img src="https://img.shields.io/badge/SUBSRIBE TO CHANNEL-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

</p>


# Setup For Deployment 👇

- FORK THE REPOSITORY [Here](https://github.com/Rashmikyhyi/RASH-MD-V1/fork))


## ` Pair with WhatsApp`
<h2 align="left">  <a href="https://nnn-4mv7.onrender.com/pair"><img src="https://play-lh.googleusercontent.com/901aMQFFnVoX2T-YuJmTIwpPve_SUgMv_QSyzMSPtAqt_l0CyXN1DxfD6xXU0r2f9iM=w240-h480-rw" width="90" />
</a>
</h2>

## DEPLOY WITH


<br>
  <a href="https://github.com/codespaces/new"><img title="A17 on Gitub Codespace" src="https://img.shields.io/badge/DEPLOY CODESPACE-h?color=black&style=for-the-badge&logo=visualstudiocode" />
</a>
  <br>
  ## Deploy on Panel
 1. First You Have to Sign up on discord using web or app then click below.
2. [Sign Up On Panel](https://dashboard.katabump.com/auth/login#674583) if you don’t have Already.
4. Click the button below to deploy using Panel:
   <br>
   <a href='https://dashboard.katabump.com/auth/login#674583' target="_blank">
      <img alt='Deploy in Panel' src='https://img.shields.io/badge/-DEPLOY-green?style=for-the-badge&logo=Cloudflare&logoColor=white'/>
   </a>
   
      **Tutorial For Panel**
1. First You Have to Sign up on discord using web or app download from playstore.
   <br>
   <a href='https://youtube.com/@HansTech0' target="_blank">
      <img alt='Deployment Tutorial' src='https://img.shields.io/badge/-Tutorial-red?style=for-the-badge&logo=youtube&logoColor=white'/>
   </a>

# Install Manually 👇

## `Requirements`

* [Node.js](https://nodejs.org/en/)

* [Git](https://git-scm.com/downloads)

* [FFmpeg](https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2020-12-08-13-03/ffmpeg-n4.3.1-26-gca55240b8c-win64-gpl-4.3.zip)

* [Libwebp](https://developers.google.com/speed/webp/download)

* Any text editor

## ` BUILDPACKS`

```


https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest

https://github.com/clhuang/heroku-buildpack-webp-binaries.git

```

## `For Termux/Ssh/Ubuntu`
CHECK IN THE [WIKI](https://github.com/Rashmikyhyi/RASH-MD-V1/fork)

INFO 

YOU DO NOT HAVE THE RIGHT TO MODIFY REPO IN ANY WAY ANY HOW 

