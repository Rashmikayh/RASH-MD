
function convertToBool(text, fault = 'true') {
    return text === fault ? true : false;
}
module.exports = {
SESSION_ID: process.env.SESSION_ID || "ANJU-XPRO~PYl1yRLJ#vtVQthKuitp9kcDEF7sKVi-cH1bm3WbK-XqxaSP7noE",  // DO NOT CHANGE THIS !!!
ALIVE_IMG: process.env.ALIVE_IMG || "https://files.catbox.moe/mgneph.jpg",
ALIVE_MSG: process.env.ALIVE_MSG || "HEY DEAR, I'm thrilled to announce that Rash e Md is ALIVE now—ready to dive into new adventures with you!",
SUDO_NB: process.env.SUDO_NB || "94769940690",
AUTO_READ_STATUS: process.env.AUTO_READ_STATUS || "false",
MODE: process.env.MODE || "public",
AUTO_VOICE:"true",
OMDB_API_KEY: "5e339fb7",
OWNER_NAME: process.env.OWNER_NAME || "RASHMIKA",
AUTO_TYPING: process.env.AUTO_TYPING || "true",
ALWAYS_ONLINE: process.env.ALWAYS_ONLINE || "true"
};
